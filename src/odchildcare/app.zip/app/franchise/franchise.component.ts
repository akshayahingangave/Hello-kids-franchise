import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-franchise',
  templateUrl: './franchise.component.html',
  styleUrls: ['./franchise.component.css']
})
export class FranchiseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
