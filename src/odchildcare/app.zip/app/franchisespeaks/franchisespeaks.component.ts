import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-franchisespeaks',
  templateUrl: './franchisespeaks.component.html',
  styleUrls: ['./franchisespeaks.component.css']
})
export class FranchisespeaksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
