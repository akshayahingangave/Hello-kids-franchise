import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-benifits',
  templateUrl: './benifits.component.html',
  styleUrls: ['./benifits.component.css']
})
export class BenifitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
